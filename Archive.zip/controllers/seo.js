(function () {
    angular.module('app', ['getglossyApp', 'seo']);
})();